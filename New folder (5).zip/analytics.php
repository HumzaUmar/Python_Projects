<?php include 'header.php';?>

  <div class="container-fluid">
  <br>
  <br>
  <center><h1>−− QUICK STATISTICS −−</h1></center> 
  <br>
  <br>
  <div class="row">
   <div class="col-sm-2">
  <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
  <div class="card-header"><center><h4>Daily Accessory</h4></center></div>
  <div class="card-body">
    <center><h2 class="card-title">75869</h2> </center>
  </div>
  </div>
</div>

 <div class="col-sm-2">
<div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
 <div class="card-header"><center><h4>Daily Accessory</h4></center></div>
  <div class="card-body">
    <center><h2 class="card-title">75869</h2> </center>
  </div>
</div>
</div>

 <div class="col-sm-2">
<div class="card text-white bg-success mb-3" style="max-width: 18rem;">
 <div class="card-header"><center><h4>Daily Accessory</h4></center></div>
  <div class="card-body">
    <center><h2 class="card-title">75869</h2> </center>
  </div>
</div>
</div>

 <div class="col-sm-2">
<div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
<div class="card-header"><center><h4>Daily Accessory</h4></center></div>
  <div class="card-body">
    <center><h2 class="card-title">75869</h2> </center>
  </div>
</div>
</div>


 <div class="col-sm-2">
<div class="card text-white bg-warning mb-3" style="max-width: 18rem;">
<div class="card-header"><center><h4>Daily Accessory</h4></center></div>
  <div class="card-body">
    <center><h2 class="card-title">75869</h2> </center>
  </div>
</div>
</div>

 <div class="col-sm-2">
<div class="card text-white bg-info mb-3" style="max-width: 18rem;">
<div class="card-header"><center><h4>Daily Accessory</h4></center></div>
  <div class="card-body">
    <center><h2 class="card-title">75869</h2> </center>
  </div>
</div>
</div>



</div>


  </div>

</body>
</html>
